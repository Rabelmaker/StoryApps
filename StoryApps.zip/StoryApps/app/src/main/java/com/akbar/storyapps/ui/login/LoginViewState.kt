package com.akbar.storyapps.ui.login

import com.akbar.storyapps.utils.ResultState

data class LoginViewState(
    val resultVerifyUser: ResultState<String> = ResultState.Idle()
)
