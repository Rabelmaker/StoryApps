package com.akbar.storyapps.domain.entity

data class UserEntity(
    val id: String,
    val name: String,
    val token: String,
)
