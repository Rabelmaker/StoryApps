package com.akbar.storyapps.ui.add_story

import com.akbar.storyapps.utils.ResultState

data class AddStoryViewState(
    val resultAddStory: ResultState<String> = ResultState.Idle()
)
