package com.akbar.storyapps.data.response

data class GeneralResponse(
    val error: Boolean,
    val message: String
)