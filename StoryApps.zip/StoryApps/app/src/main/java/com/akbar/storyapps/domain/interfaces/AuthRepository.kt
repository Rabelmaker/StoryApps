package com.akbar.storyapps.domain.interfaces

import com.akbar.storyapps.data.response.GeneralResponse
import com.akbar.storyapps.data.response.LoginResponse
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    fun register(email: String, password: String, name: String): Flow<GeneralResponse>
    fun login(email: String, password: String): Flow<LoginResponse>
}