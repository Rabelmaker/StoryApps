package com.akbar.storyapps.ui.story

import com.akbar.storyapps.domain.entity.StoryEntity
import com.akbar.storyapps.utils.ResultState


data class StoryViewState(
    val resultStories: ResultState<List<StoryEntity>> = ResultState.Idle(),
    val username: String = "",
)