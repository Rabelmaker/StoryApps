package com.akbar.storyapps

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.akbar.storyapps.data.repository.AuthRepositoryImpl
import com.akbar.storyapps.data.repository.StoryRepositoryImpl
import com.akbar.storyapps.data.source.local.UserPreferenceImpl
import com.akbar.storyapps.data.source.remote.RetrofitBuilder
import com.akbar.storyapps.domain.usecase.*
import com.akbar.storyapps.ui.add_story.AddStoryViewModel
import com.akbar.storyapps.ui.detail_story.StoryDetailViewModel
import com.akbar.storyapps.ui.login.LoginViewModel
import com.akbar.storyapps.ui.register.RegisterViewModel
import com.akbar.storyapps.ui.story.StoryViewModel
import com.akbar.storyapps.ui.welcome.WelcomeViewModel

object Locator {
    private var application: Application? = null

    private inline val requireApplication
        get() = application ?: error("Missing call: initWith(application)")

    fun initWith(application: Application) {
        this.application = application
    }

    // Data Store
    private val Context.dataStore by preferencesDataStore(name = "user_preferences")

    // ViewModel Factory
    val loginViewModelFactory
        get() = LoginViewModel.Factory(
            loginUseCase = loginUseCase
        )
    val registerViewModelFactory
        get() = RegisterViewModel.Factory(
            registerUseCase = registerUseCase
        )
    val welcomeViewModelFactory
        get() = WelcomeViewModel.Factory(
            getUserUseCase = getUserUseCase
        )
    val storyViewModelFactory
        get() = StoryViewModel.Factory(
            getStoriesUseCase = getStoriesUseCase,
            getUserUseCase = getUserUseCase,
            logoutUseCase = logoutUseCase
        )
    val storyDetailViewModelFactory
        get() = StoryDetailViewModel.Factory(
            getStoryDetailUseCase = getStoryDetailUseCase
        )
    val addStoryViewModelFactory
        get() = AddStoryViewModel.Factory(
            addStoryUseCase = addStoryUseCase
        )

    // UseCases Injection
    private val loginUseCase get() = LoginUseCase(userPreferencesRepository, authRepository)
    private val registerUseCase get() = RegisterUseCase(authRepository)
    private val getUserUseCase get() = GetUserUseCase(userPreferencesRepository)
    private val getStoriesUseCase get() = GetStoriesUseCase(storyRepository)
    private val logoutUseCase get() = LogoutUseCase(userPreferencesRepository)
    private val getStoryDetailUseCase get() = GetStoryDetailUseCase(storyRepository)
    private val addStoryUseCase get() = AddStoryUseCase(storyRepository)

    // Repository Injection
    private val userPreferencesRepository by lazy {
        UserPreferenceImpl(requireApplication.dataStore)
    }
    private val authRepository by lazy {
        AuthRepositoryImpl(RetrofitBuilder(requireApplication.dataStore).apiService)
    }
    private val storyRepository by lazy {
        StoryRepositoryImpl(RetrofitBuilder(requireApplication.dataStore).apiService)
    }
}