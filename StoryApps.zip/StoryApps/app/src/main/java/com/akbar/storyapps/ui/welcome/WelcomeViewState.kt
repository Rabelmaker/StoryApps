package com.akbar.storyapps.ui.welcome

import com.akbar.storyapps.utils.ResultState

data class WelcomeViewState(
    val resultIsLoggedIn: ResultState<Boolean> = ResultState.Idle()
)
