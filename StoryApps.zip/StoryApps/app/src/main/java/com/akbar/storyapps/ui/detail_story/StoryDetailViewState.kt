package com.akbar.storyapps.ui.detail_story
import com.akbar.storyapps.domain.entity.StoryEntity
import com.akbar.storyapps.utils.ResultState

data class StoryDetailViewState(
    val resultStory: ResultState<StoryEntity> = ResultState.Idle()
)