package com.akbar.storyapps.ui.register

import com.akbar.storyapps.utils.ResultState

data class RegisterViewState(
    val resultRegisterUser: ResultState<String> = ResultState.Idle()
)