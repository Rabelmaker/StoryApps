package com.akbar.storyapps.domain.usecase

import com.akbar.storyapps.domain.entity.UserEntity
import com.akbar.storyapps.domain.interfaces.UserPreferenceRepository
import kotlinx.coroutines.flow.Flow

class GetUserUseCase(private val userPreferenceRepository: UserPreferenceRepository) {
    operator fun invoke(): Flow<UserEntity> = userPreferenceRepository.userData
}